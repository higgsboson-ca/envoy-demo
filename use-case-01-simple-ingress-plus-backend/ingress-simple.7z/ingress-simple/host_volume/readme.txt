This is the folder hosting runtime files for docker instance. It is populated when docker images are built.
