package bnl.sb2.rest.poc.customerChecker.dao;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.stereotype.Repository;

import bnl.sb2.rest.poc.customerChecker.model.Customer;
import bnl.sb2.rest.poc.customerChecker.model.Customers;

@Repository
public class CustomerDAO 
{
	private static Customers list = new Customers();
	
	static 
	{
		int initSize = Integer.parseInt(System.getProperty("init_list_size"));
		// about 125 bytes per record
		list.getCustomerList().add(new Customer(1, "Brian", "Brian", "brian.brianbrian@mymail-canada.com"));
		list.getCustomerList().add(new Customer(2, "Sameer", "Sameer", "sameer.sameersameer@mymail-canada.com"));
		list.getCustomerList().add(new Customer(3, "Vinod", "Sameer", "vinod.vinodvinod@mymail-canada.com"));

		// make about 125K bytes for 1K records. white space between : are included.
		// make about 1.25M bytes for 10K records.
		for (int i=4; i<=initSize; i++) {
			String fName = RandomStringUtils.randomAlphabetic(6).toLowerCase();
			String lName = RandomStringUtils.randomAlphabetic(8).toLowerCase();
			String emailName = fName + "." + lName;
			String emailDomain = RandomStringUtils.randomAlphabetic(8).toLowerCase();
			String dotCom = RandomStringUtils.randomAlphabetic(3).toLowerCase();
			list.getCustomerList().add(new Customer(i, fName, lName, emailName + "@" + emailDomain + "." + dotCom));
		}
	}

	public Customers getAllCustomers() 
	{
		return list;
	}

	public Customer getCustomer(int num) 
	{
		if (num < list.getCustomerList().size())
			return list.getCustomerList().get(num);
		else return null;
	}

	public void addCustomer(Customer customer) {
		list.getCustomerList().add(customer);
	}
}
