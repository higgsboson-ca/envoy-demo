package bnl.sb2.rest.poc.customerChecker.filter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.util.ContentCachingResponseWrapper;

import bnl.common.servlet.io.BufferedHttpServletResponse;

//import ca.interac.etransfer.crypto.ec.Decryptor;
//import ca.interac.etransfer.crypto.ec.Encryptor;
//import ca.interac.etransfer.crypto.ec.Util;

//@Component
public class PayloadLogger {
	private static final Logger logger = LogManager.getLogger("PayloadLogger");

	static PayloadLogger pl = null;
	static boolean encryption_flag = false;

//	static Encryptor enc;

	private PayloadLogger() {
		// for singleton
	}

	// singleton instance
	public static PayloadLogger getInstance() {
		if (pl == null) {
			pl = new PayloadLogger();
//			enc = new Encryptor(System.getProperty("payload.encryption.public.key"));
		}
		return pl;
	}

	//    @Autowired
	//    private ApplicationContext appContext;

	public void logRequestPayload(HttpServletRequest request, 
			String epid, String etid, String rqid)
					throws IOException, ServletException {

		StringBuilder sb = new StringBuilder();
		
		// handle title logging
		sb.append("\n[REQUEST] -- [FI-ID = ").append(epid)
			.append("] [ET-Request-ID = ")
			.append(etid).append("] [")
			.append(request.getMethod())
			.append("]\n");
		
		sb.append("- [REQUEST_URL] -- ").append(request.getServletPath()); // getContextPath does not work at this stage
		if (request.getQueryString()!=null && request.getQueryString().trim().length()>0) // log the query parameters if presented
			sb.append("?").append(request.getQueryString());
		sb.append("\n");
		
		// handle header logging
		sb.append("- [HTTP_REQUEST_HEADERS] -- \n");
		Enumeration<String> headerEnum = request.getHeaderNames();
		while (headerEnum.hasMoreElements()) {
			String head = headerEnum.nextElement();
			sb.append("- - [HEADER] -- ").append(head).append(" : ").append(request.getHeader(head)).append("\n");
		}

		// handle body
//		String encString = "";
		try {
			String payload = loadBodyByStream(request.getInputStream());
			if (payload != null && payload.length()>0) {
				if (encryption_flag) {
//				encString = enc.doEncryption(payload);
//				sb.append("- [HTTP_REQUEST_BODY_ENC] -- ").append(encString).append("\n");
				} else 
					sb.append("- [HTTP_REQUEST_BODY] -- \n").append(payload).append("\n");

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.error(sb.toString());
	}

	public void logRequestPayload(HttpServletRequest request, String reqBodyString,
			String epid, String etid, String rqid)
					throws IOException, ServletException {

		StringBuilder sb = new StringBuilder();
		
		// handle title logging
		sb.append("\n[REQUEST] -- [FI-ID = ").append(epid)
			.append("] [ET-Request-ID = ")
			.append(etid).append("] [")
			.append(request.getMethod())
			.append("]\n");
		
		sb.append("- [REQUEST_URL] -- ").append(request.getServletPath()); // getContextPath does not work at this stage
		if (request.getQueryString()!=null && request.getQueryString().trim().length()>0) // log the query parameters if presented
			sb.append("?").append(request.getQueryString());
		sb.append("\n");
		
		// handle header logging
		sb.append("- [HTTP_REQUEST_HEADERS] -- \n");
		Enumeration<String> headerEnum = request.getHeaderNames();
		while (headerEnum.hasMoreElements()) {
			String head = headerEnum.nextElement();
			sb.append("- - [HEADER] -- ").append(head).append(" : ").append(request.getHeader(head)).append("\n");
		}

		// handle body
//		String encString = "";
		if (encryption_flag) {
//			encString = enc.doEncryption(payload);
//			sb.append("- [HTTP_REQUEST_BODY_ENC] -- ").append(encString).append("\n");
			} else 
				sb.append("- [HTTP_REQUEST_BODY] -- \n").append(reqBodyString).append("\n");

		logger.error(sb.toString());
	}

	public void logResponsePayload(ContentCachingResponseWrapper responseWrapper, 
			String epid, String etid, String rqid)
					throws IOException, ServletException {
        String payload = new String(responseWrapper.getContentAsByteArray());

		// handle header logging
		StringBuilder sb = new StringBuilder();
		sb.append("\n[RESPONSE] -- [FI-ID = ").append(epid).append("] [ET-Request-ID = ").append(etid).append("]\n");

		sb.append("- [HTTP_RESPONSE_HEADERS] -- \n");
		
		Collection<String> headerCollection = responseWrapper.getHeaderNames();
		Iterator<String> it = headerCollection.iterator();
		
		while (it.hasNext()) {
			String head = it.next();
			sb.append("- - [HEADER] -- ").append(head).append(" : ").append(responseWrapper.getHeader(head)).append("\n");
		}

		// handle body
//		String encString = "";
		try {
			if (payload != null && payload.length()>0) {
//				encString = enc.doEncryption(payload);
//				sb.append("- [HTTP_RESPONSE_BODY_ENC] -- ").append(encString).append("\n");
				sb.append("- [HTTP_RESPONSE_BODY] -- ").append(payload).append("\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.error(sb.toString());
	}
	
	String loadBodyByReader (HttpServletRequest request) throws Exception {
		StringBuilder strBuilder = new StringBuilder();
		BufferedReader reader = request.getReader();
		String line;
		while ((line = reader.readLine()) != null) {
			strBuilder.append(line);
		}
		return strBuilder.toString();
	}

	String loadBodyByStream(InputStream inputStream) throws IOException {

	    String body = null;
	    StringBuilder stringBuilder = new StringBuilder();
	    BufferedReader bufferedReader = null;

	    try {
	        if (inputStream != null) {
	            bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
	            char[] charBuffer = new char[1024];
	            int bytesRead = -1;
	            while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
	                stringBuilder.append(charBuffer, 0, bytesRead);
	            }
	        } else
	            stringBuilder.append("");

	    } catch (IOException ex) {
	    	throw ex;
	    } 
//	    finally {
//	        if (bufferedReader != null)
//	            try { bufferedReader.close();} catch (IOException ex) {throw ex;}
//	    }

	    body = stringBuilder.toString();
	    return body;
	}

	public void logResponsePayload(BufferedHttpServletResponse responseWrapper, 
			String epid, String etid, String rqid)
					throws IOException, ServletException {
		String payload = new String(responseWrapper.getContent());

		// handle header logging
		StringBuilder sb = new StringBuilder();
		sb.append("\n[RESPONSE] -- [FI-ID = ").append(epid).append("] [ET-Request-ID = ").append(etid).append("]\n");

		sb.append("- [HTTP_RESPONSE_HEADERS] -- \n");

		Collection<String> headerCollection = responseWrapper.getHeaderNames();
		Iterator<String> it = headerCollection.iterator();

		while (it.hasNext()) {
			String head = it.next();
			sb.append("- - [HEADER] -- ").append(head).append(" : ").append(responseWrapper.getHeader(head)).append("\n");
		}

		// handle body
		//		String encString = "";
		try {
			if (payload != null && payload.length()>0) {
				//				encString = enc.doEncryption(payload);
				//				sb.append("- [HTTP_RESPONSE_BODY_ENC] -- ").append(encString).append("\n");
				sb.append("- [HTTP_RESPONSE_BODY] -- ").append(payload).append("\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		logger.error(sb.toString());
	}

}
