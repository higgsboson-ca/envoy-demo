package bnl.sb2.rest.poc.customerChecker;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import bnl.crypto.ec.Decryptor;
import bnl.crypto.ec.Encryptor; 

@SpringBootApplication
@ComponentScan(basePackages = "bnl.sb2.rest.poc")
public class MainApp {

	static Encryptor enc;
	static Decryptor denc;
	private static final Logger logger = LogManager.getLogger(MainApp.class);

//    @Bean("payload_encryptor")
//    public static Encryptor initEncryptor() {
//		return enc = new Encryptor(System.getProperty("payload.encryption.public.key"));
//    }
//
//    @Bean("payload_decryptor")
//    public static Decryptor initDecryptor() {
//    	return denc = new Decryptor(System.getProperty("payload.decryption.private.key"));
//    }
//
    public static void main(String[] args) {
    	// Init the property for the crypto utils
//    	logger.info("Loading crypto properties");
//		Util.loadCrypotProperies("./sanity-conf/crypto.properties");
        SpringApplication.run(MainApp.class, args);
    }
}
