package bnl.sb2.rest.poc.customerChecker.controller;

import java.net.URI;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import bnl.sb2.rest.poc.customerChecker.dao.CustomerDAO;
import bnl.sb2.rest.poc.customerChecker.model.Customer;
import bnl.sb2.rest.poc.customerChecker.model.Customers;

@RestController
@RequestMapping(path = "/customers")
public class CustomerController 
{
	private static final Logger logger = LogManager.getLogger(CustomerController.class);

    @Autowired
    private CustomerDAO customerDao;
    
    @GetMapping(path="/list", produces = "application/json")
    public Customers getCustomers() {
    	logger.info("GET BEGIN");
        return customerDao.getAllCustomers();
    }
    
    @PostMapping(path= "/post", consumes = "application/json", produces = "application/json")
    public ResponseEntity<Object> addCustomer(
                        @RequestHeader(name = "x-et-request-id", required = true, defaultValue = "abcdef") String requestId,
                        @RequestHeader(name = "x-et-participant-id", required = true, defaultValue = "123321") String participantId,
                        @RequestHeader(name = "x-request-id", required = true, defaultValue = "0-2-3-4-5-6") String sessionId,
                        @RequestBody(required=true) Customer customer) 
                 throws Exception {
    	logger.info("POST BEGIN");
        //Generate resource id
        Integer id = customerDao.getAllCustomers().getCustomerList().size() + 1;
        customer.setId(id);
        
        //add resource
        customerDao.addCustomer(customer);
        
        //Create resource location
        URI location = ServletUriComponentsBuilder.fromCurrentRequest()
                                    .path("/{id}")
                                    .buildAndExpand(customer.getId())
                                    .toUri();
        
    	logger.info("POST END");
        //Send location in response
        return ResponseEntity.created(location).build();
    }
}
