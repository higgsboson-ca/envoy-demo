package bnl.sb2.rest.poc.customerChecker.filter;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import bnl.common.servlet.io.BufferedHttpServletRequestWrapper;
import bnl.common.servlet.io.BufferedHttpServletResponse;

@Component
public class RequestFilter implements Filter {

	private static final Logger logger = LogManager.getLogger(RequestFilter.class);

	PayloadLogger bizLog = PayloadLogger.getInstance();
	
	@Value("${bnl.app.name:generic-bnlapp}")
    String appName;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res,
                         FilterChain chain) throws IOException, ServletException {
        long beginLong = System.currentTimeMillis();
        try {
            String epid = "BNL";
            String etid = "test-tx-123";
            String rqid = "LOCAL-GEN-" + UUID.randomUUID().toString();
;
            HttpServletRequest httpServletRequest = (HttpServletRequest) req;
            HttpServletResponse httpServletResponse = (HttpServletResponse) res;

            BufferedHttpServletRequestWrapper bufferedRequest = new BufferedHttpServletRequestWrapper(
                    httpServletRequest);
            BufferedHttpServletResponse bufferedResponse = new BufferedHttpServletResponse(
                    httpServletResponse);

            ThreadContext.put("epid", epid);
            ThreadContext.put("etid", etid);
            ThreadContext.put("rqid", rqid);
            ThreadContext.put("etappnameid", appName);

            String reqBodyStr = bufferedRequest.getRequestBody();
            //logger.info("log payload \n" + reqBodyStr);
            bizLog.logRequestPayload(bufferedRequest, reqBodyStr, epid, etid, rqid);
            try {
            	chain.doFilter(bufferedRequest, bufferedResponse);
            } finally {
                //logger.info("log payload \n" + bufferedResponse.getContent());
            	bizLog.logResponsePayload(bufferedResponse, epid, etid, rqid);
            }
        } catch (Exception a) {
        	logger.error(a.getMessage());
        } finally {
            logger.info("Total Processing Time (ms) : " + (System.currentTimeMillis()-beginLong));

            // drop log tracing id
            ThreadContext.remove("rqid");
            ThreadContext.remove("etid");
            ThreadContext.remove("epid");
            ThreadContext.remove("etappnameid");

        }
    }

    @Override
    public void destroy() {
    }
}
