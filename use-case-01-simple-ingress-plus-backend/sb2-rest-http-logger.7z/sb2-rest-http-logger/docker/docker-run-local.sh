#!/bin/bash
docker_run_folder="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
APP_NAME=sb2-rest-http-logger

# stop the instance if it is running
echo "... try to stop the instance if it is running ..."
docker stop $APP_NAME

cd $docker_run_folder

if [ ! -d $docker_run_folder/payload-log ]; then
    mkdir $docker_run_folder/payload-log
fi

if [ ! -f $docker_run_folder/local.env ]; then
    cp $docker_run_folder/default.env $docker_run_folder/local.env
fi

read -p "Please update the local.env for this environemnt ... CTRL+C to stop"
exposed_server_port=8181
internal_server_port=8080
echo "... Starting server on port $exposed_server_port ..."
docker run -d --rm --env-file $docker_run_folder/local.env \
	-v $docker_run_folder/payload-log:/home/bnlapp/$APP_NAME/payload-log:Z \
	-v $docker_run_folder/../ec-key:/home/bnlapp/$APP_NAME/ec-key:Z \
	-p $exposed_server_port:$internal_server_port \
	--name $APP_NAME \
	$APP_NAME:latest


dkid=$(docker ps | grep $APP_NAME | awk '{ print $1 }')
docker logs -f $dkid &
unset docker_run_folder
unset APP_NAME
unset dkid
