#!/bin/sh
APP_NAME=sb2-rest-http-logger

echo "... logging into docker-hub with bnlcnd ... password might be required ..."
docker login --username=bnlcnd

docker tag $APP_NAME:latest bnlcnd/$APP_NAME:latest
docker push bnlcnd/$APP_NAME:latest
unset APP_NAME

