#!/bin/bash
docker_build_folder="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# init variables for easy reading. 
# APP_NAME should be image name and also the home folder name of the app.
GROUP_USER_ID=610
APP_NAME=sb2-rest-http-logger
APP_JAR_NAME=sb2-rest-http-logger.jar

# stop before build
echo "... try to stop the instance if it is running ..."
docker stop $APP_NAME

# maven build must start from the project root
cd $docker_build_folder/..
. ./run-mvn-local.sh
cp $docker_build_folder/../target/$APP_JAR_NAME $docker_build_folder/
cd $docker_build_folder

# clean old images
docker images --no-trunc | grep $APP_NAME | awk '{ print $3 }' | xargs -r docker rmi -f
build_time=`date +%Y%m%d-%H%M%S-%Z`

docker build --no-cache --build-arg GROUP_USER_ID=$GROUP_USER_ID --build-arg APP_NAME=$APP_NAME \
    --build-arg APP_JAR_NAME=$APP_JAR_NAME \
    -t $APP_NAME:$build_time $docker_build_folder

# tag the image
docker tag $APP_NAME:$build_time $APP_NAME:latest

cd $docker_build_folder

rm $docker_build_folder/${APP_JAR_NAME}

unset build_time
unset docker_build_folder
unset GROUP_USER_ID
unset APP_NAME
unset APP_JAR_NAME
