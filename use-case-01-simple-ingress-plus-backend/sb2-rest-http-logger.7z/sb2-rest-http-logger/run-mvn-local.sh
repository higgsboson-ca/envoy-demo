#!/bin/sh
mvn_home_folder="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

cd $mvn_home_folder
mvn clean install -Dmaven.test.skip=true

unset mvn_home_folder
