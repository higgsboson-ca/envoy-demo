package bnl.sb2.rest.poc.customerChecker.filter;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.UUID;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.stereotype.Component;

@Component
public class LoggerFilter implements Filter {
	private static final Logger logger = LogManager.getLogger(LoggerFilter.class);

	PayloadLogger bizLog = PayloadLogger.getInstance();
	
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {

        if (req instanceof HttpServletRequest) {
            HttpServletRequest request = (HttpServletRequest) req;
            HttpServletResponse response = (HttpServletResponse) res;

            // Handle log treacing id
            String epid = request.getHeader("x-et-participant-id");
            String etid = request.getHeader("x-et-request-id");
            if (epid == null || etid == null) throw new ServletException("required headers are missing");
            String rqid = request.getHeader("x-request-id");
            rqid = rqid != null ? rqid : this.getClass().getPackage().getName() + "." + UUID.randomUUID().toString();
            
            ThreadContext.put("epid", epid);
            ThreadContext.put("etid", etid);
            ThreadContext.put("rqid", rqid);

            bizLog.logPayload(request, response, epid, etid, rqid);
            
        } else 
        	throw new IOException(" NOT A SERVLET REQUEST");

        try {
            chain.doFilter(req, res);
        } finally {
            ThreadContext.remove("rqid");
            ThreadContext.remove("etid");
            ThreadContext.remove("epid");
        }
        
    }

    String readHttpBody (HttpServletRequest request) throws Exception {
        StringBuilder strBuilder = new StringBuilder();
        BufferedReader reader = request.getReader();
        String line;
        while ((line = reader.readLine()) != null) {
            strBuilder.append(line);
        }
        return strBuilder.toString();
    }
    
    @Override
    public void destroy() {
        // nothing
    }

    @Override
    public void init(FilterConfig fc) throws ServletException {
        // nothing
    }
}
