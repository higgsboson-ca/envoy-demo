#!/bin/bash
APP_JAR_NAME=sb2-rest-http-logger.jar

run_folder="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

cd $run_folder/target
if [ ! -d $run_folder/target/payload-log ]; then
    mkdir $run_folder/target/payload-log
fi

JAVA_OPTS="-Xms256m -Xmx4096m -XX:+UseG1GC"

# set to FATAL to turn off payload log
# BNL_PAYLOAD_LOG_LEVEL=FATAL
# set to ERROR to turn on payload log
BNL_PAYLOAD_LOG_LEVEL=ERROR

# true/false to turn on/off gzip
GZIP_FLAG=false

# init customer list size. about 125 bytes per record.
# 100=12.5K, 500=62.5K, 1000=125K, 10000-1.25M
INIT_LIST_SIZE=1000

#BNL_PAYLOAD_LOG_OUTPUT=Console
BNL_PAYLOAD_LOG_OUTPUT=payloadlog-split

BNL_LOG_ROOT_LEVEL=INFO
BNL_LOG_LEVEL=INFO
BNL_PAYLOAD_LOG_FOLDER=./payload-log



java $JAVA_OPTS -DBNL_PAYLOAD_LOG_LEVEL=$BNL_PAYLOAD_LOG_LEVEL -DBNL_PAYLOAD_LOG_OUTPUT=$BNL_PAYLOAD_LOG_OUTPUT  -DBNL_PAYLOAD_LOG_FOLDER=$BNL_PAYLOAD_LOG_FOLDER -DBNL_LOG_ROOT_LEVEL=$BNL_LOG_ROOT_LEVEL -DBNL_LOG_LEVEL=$BNL_LOG_LEVEL -Dgzip_flag=$GZIP_FLAG -Dinit_list_size=$INIT_LIST_SIZE -Drun.jvmArguments=-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=8787 -jar $run_folder/target/$APP_JAR_NAME

cd $run_folder

unset run_folder
unset APP_JAR_NAME
